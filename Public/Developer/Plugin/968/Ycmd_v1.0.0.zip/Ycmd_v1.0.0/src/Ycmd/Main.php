<?php

namespace Ycmd;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\tile\Sign;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\tile\Tile;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener{
    private $api, $server, $path;

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("  \n\n\n（！！！！！低调！！！！！）\n\n (●—●)Ycmdsign(●—●)\n▲    （一个神奇的指令木牌插件） ▲\n→→→作者xMing←←←\n\n（！！！！！！低调！！！！！！）\n\n");
        $this->getLogger()->info("\n使用方法:第一行随便▲第二行yc▲第三第四行指令不带斜杠\n");
}
    public function playerBlockTouch(PlayerInteractEvent $event){
        if($event->getBlock()->getID() == 323 || $event->getBlock()->getID() == 63 || $event->getBlock()->getID() == 68){
            $sign = $event->getPlayer()->getLevel()->getTile($event->getBlock());
            if(!($sign instanceof Sign)){
                return;
            }
            $sign = $sign->getText();
            if($sign[1] == 'yc' or $sign[1] == 'yc'){
                if(isset($sign[2])){
                    $command = $sign[2].$sign[3];
                    $event->getPlayer()->sendMessage("");
					$this->getServer()->dispatchCommand($event->getPlayer(), $command);
                    
                }
            }
        }
    }
}
