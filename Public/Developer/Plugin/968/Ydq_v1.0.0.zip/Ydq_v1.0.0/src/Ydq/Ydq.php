<?php
namespace Ydq;


use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\utils\TextFormat;

class Ydq extends PluginBase implements Listener{

public function onEnable(){
$this->getLogger()->info("\n\n\n（！！！！！低调！！！！！）\n\n (●—●)Ydq(●—●)\n▲    （一个神奇的创造禁止丢弃插件） ▲\n→→→作者xMing←←←\n\n（！！！！！！低调！！！！！！）\n\n");
$this->getLogger()->info(TextFormat::GREEN."作者:xMing");
$this->getServer()->getPluginManager()->registerEvents ( $this, $this );
}
public function onScc(PlayerDropItemEvent $e){
$p=$e->getPlayer();
if($e->getPlayer()->getGamemode(1)){
$e->setCancelled(true);
$p->sendMessage("§a创造模式禁止丢弃物品");}
   }
}
?>