<?php

namespace EAEvent;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerBedLeaveEvent;
use pocketmine\event\player\PlayerBedEnterEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\level\sound\FizzSound;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound\LaunchSound;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\DoorSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\particle\HugeExplodeParticle;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\Particle;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener
{	
        public function OnEnable(){
			    $this->getServer()->getPluginManager()->registerEvents($this, $this);
                $this->getServer()->getLogger()->info("§a欢迎使用§eEAEvent");
        }
		
        public function OnLoad() {
                $this->getServer()->getLogger()->info("§eEAEvent§c正在加载!");
        }
        
        public function OnDisable() {
                $this->getLogger()->info("§eEAEvent§c卸载成功");
        }
        public function OnDeath(PlayerDeathEvent $event){
             $player = $event->getPlayer();
        	$player->getLevel()->addSound(new FizzSound($player));
                $player->sendMessage("§7============");
                $player->sendMessage("§7==§c你死了!§7==");
                $player->sendMessage("§7============");
        }
        public function OnJoin(PlayerJoinEvent $event){
                $player = $event->getPlayer();
        	    $player->getLevel()->addSound(new DoorSound($player));
                $x=$player->x;
                $y=$player->y;
                $z=$player->z;
                $player->getLevel()->addParticle(new HugeExplodeParticle(new Vector3($x,$y,$z)));
				$player->getLevel()->addParticle(new HugeExplodeParticle(new Vector3($x+1,$y+1 ,$z+1)));
        }
        
        public function onHold(PlayerItemHeldEvent $event){
			if($this->config->get("PlayerItemHeldEvent", true)){
                $player = $event->getPlayer();
            if($event->getItem()->getId() == 46){
                $player->sendPopup($this->prefix."清空背包...");
                $player->getInventory()->clearAll();
				$player->getLevel()->addSound(new PopSound($player));
            }
            if($event->getItem()->getId() == 347){
                $player->sendPopup("§a回到出生点!");
				$x=$player->x;
                $y=$player->y;
                $z=$player->z;
				$player->getLevel()->addSound(new PopSound($player));
				$player->getLevel()->addParticle(new HugeExplodeParticle(new Vector3($x, $y, $z)));
			}
            }
        }
		
        public function OnInteract(PlayerInteractEvent $event){
        	$item=$event->getItem();
        	$player=$event->getPlayer();
        	$spawn = $this->getServer()->getDefaultLevel()->getSafeSpawn();
        	if($item->getId()==347){
        		$player->teleport($spawn);
                        $x=$player->x;
                        $y=$player->y;
                        $z=$player->z;
		        $player->getLevel()->addParticle(new LargeExplodeParticle(new Vector3($x + 2, $y + 2, $z + 2)));
		        $player->sendMessage("§6传送到出生点!");
			}
        }
        
        public function OnDrop(PlayerDropItemEvent $event) {
                $player = $event->getPlayer();
                $player->sendMessage("§b不许乱扔垃圾");
                $player->getLevel()->addSound(new ClickSound($player));
                $x=$player->x;
                $y=$player->y;
                $z=$player->z;
                $player->getLevel()->addParticle(new LargeExplodeParticle(new Vector3($x + 2, $y + 2, $z + 2)));
        }
        
        public function OnChat(PlayerChatEvent $event){
                $player = $event->getPlayer();
                $name = $player->getName();
                $player->getLevel()->addSound(new AnvilUseSound($player));
		$event->setFormat("§a§l $name ->>".$event->getMessage());
                $x=$player->x;
                $y=$player->y;
                $z=$player->z;
                $player->getLevel()->addParticle(new LargeExplodeParticle(new Vector3($x + 2, $y + 2, $z + 2)));
        }
	public function onTeleport(EntityTeleportEvent $event){
		$entity=$event->getEntity();
			if($entity instanceof Player){
				$pos=$event->getFrom();
				$entity->sendPopup("§a当前坐标: $pos");
				$entity->getLevel()->addSound(new PopSound($entity));
                $x=$player->x;
                $y=$player->y;
                $z=$player->z;
                $player->getLevel()->addParticle(new HugeExplodeParticle(new Vector3($x + 2, $y + 2, $z + 2)));
		}
	}
	public function onBEDENTER(PlayerBedEnterEvent $event){
		$player=$event->getPlayer();
			if($player instanceof Player){
				$player->sendTip("§f§lZzzZZzz..");
				$player->getLevel()->addSound(new PopSound($player));
		}
	}
	public function onBEDLeave(PlayerBedLeaveEvent $event){
		$player=$event->getPlayer();
			if($player instanceof Player){
				$player->sendTip("§6§l起床啦!");
				$player->getLevel()->addSound(new PopSound($player));
		}
	}
	public function PlayerQuitEvent(PlayerQuitEvent $event){
		$player=$event->getPlayer();
			if($player instanceof Player){
				$op=$this->getServer()->getOnlinePlayers();
				$op->BroadPopup("§b§l$player 退出了游戏.");
				$player->getLevel()->addSound(new PopSound($player));
		}
	}
}
?>
