# fhiddenmine
隐藏的矿石，使X射线modscript无效>好插件
它会检查和隐藏的矿石的位置设置在当pocketmine发送大块的球员。（默认值：48）
谢谢你的摇摆，现在可以在没有任何其他改变pocketmine 1.5 pocketmine。
：磷
#命令
/ hidemine主命令>
<世界>添加/ hidemine加入世界插件保护列表>
<世界>删除/ hidemine从清除世界保护列表>
/ hidemine列表显示保护世界>列表
/ hidemine重装重装config.yml
# <字体颜色= 30’>警告< /字体> >
不添加任何世界格式不<字体颜色=’> mcregion < /字体>在保护名单！< >
如果你这样做，世界将被打破！< >
（砧世界文件*。MCA，和mcregion世界文件*。MCR，这个插件只支持mcregion地图。
你可以打开“转换格式”pocketmine。YML，然后pocketmine将水平格式mcregion（也许）。
#其他
这个插件将禁用的。
< a href =“HTTP：/ /下载。fengberd。净/插件/ fhiddenmine /”>药学下载</a>