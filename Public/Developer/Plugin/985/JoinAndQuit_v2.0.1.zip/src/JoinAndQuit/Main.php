<?php
namespace JoinAndQuit;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\scheduler\CallbackTask;
use onebone\economyapi\EconomyAPI;
use pocketmine\inventory\Inventory;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\entity\EntityDamageByEntityEvent;

class Main extends PluginBase implements Listener{ 
public function onEnable(){
@mkdir($this->getDataFolder(),0777,true);
$this->config=new Config($this->getDataFolder()."setting.yml",Config::YAML,array(
"下面是关于插件的一些编辑",
"为了便于腐竹修改插件，所以我开通了这个接口",
"这是玩家登录提示语的编辑：",
"op加入服务器提示" => "§7[JAQ]§6伟大的op{n}来到了服务器",
"玩家加入服务器提示" => "§7[JAQ]§a欢迎玩家{n}加入本服务器",
"op退出服务器提示" => "§7[JAQ]§cop{n}退出了服务器",
"玩家退出服务器提示" => "§7[JAQ]§c玩家{n}退出了服务器",
"杀人信息提示编辑" => "§6残暴的{kill}将{killed}杀了",
"玩家死亡信息提示" => "§7[Death]§6玩家{n}挂彩了",
"玩家/op加入信息发送方式" => "message",
"玩家/op退出信息发送方式" => "message",
"玩家死亡信息发送方式" => "message",
"发送方式有：popup，message，tip",
"是否开启玩家/op加入提示" => "开启",
"是否开启玩家/op退出提示" => "开启",
"是否开启玩家死亡信息发送" => "开启",
"是否开启底部显示" => "开启",
"是否开启聊天框美化" => "关闭",
"是否开启杀人信息提示" => "开启",
"是否开启自动读取配置文件" => "关闭",
"如果不想开启请填关闭",
"下面是底部显示的编辑，注意∶{}里的的东西不要修改，否则会导致插件崩溃",
"底部显示的编辑" => "§7当前时间：{H}时{i}分{s}秒 §6你拥有金钱：{m}元 §c在线人数：{c} \n §6手持物品id：{id}∶{ts} §4你的权限：{qx} §a当前坐标：{xyz}",
"好了，配置就是这些，如果你有更好的建议，请联系我，QQ号2543036788",
));
$this->a=new Config($this->getDataFolder()."说明.txt",Config::YAML,array(
"{n}=玩家名称",
"{m}=底部显示金钱数量",
"{c}=底部显示在线玩家数量",
"{L}=底部显示所在世界名称",
"{id}=底部显示玩家手持物品id",
"{ts}=底部显示玩家手持物品id的特殊值",
"{H}=底部显示当前时间（小时）",
"{i}=底部显示当前时间（分钟）",
"{s}=底部显示当前时间（秒）",
"{qx}=底部显示玩家权限",
"{xyz}=底部显示玩家坐标",
"更多功能还在更新中..."
));
  $this->config->save();
	$this->getServer()->getPluginManager()->registerEvents($this,$this); 
  $this->getLogger()->info("欢迎使用JAQ");
  $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this,"timer"]),5);
  }

public function onDisable(){
  $this->getLogger()->info("插件已停止运行");
}

public function timer(){
$reload=$this->config->get("是否开启自动读取配置文件");
switch($reload){
case "开启":
$this->config->reload();
break;
case "关闭":
break;
}
foreach($this->getServer()->getOnlinePlayers() as $player){
date_default_timezone_set("PRC");
$count=count($this->getServer()->getOnlinePlayers());
$money=EconomyAPI::getInstance()->myMoney($player->getName());
$item=$player->getInventory()->getItemInHand();
$id=$item->getID();
$ts=$item->getDamage();
$level=$player->getLevel()->getName();
$x=intval($player->getX());
$y=intval($player->getY());
$z=intval($player->getZ());
$dbkq=$this->config->get("是否开启底部显示");
switch($dbkq){
case "开启":
if($player->isOp()){
$qx="§4管理员";
}else{
$qx="§6玩家";
}
$target=array(
"{m}",
"{L}",
"{c}",
"{id}",
"{ts}",
"{qx}",
"{H}",
"{i}",
"{s}",
"{xyz}",
);
$targets=array(
"{$money}",
"{$level}",
"{$count}",
"{$id}",
"{$ts}",
"{$qx}",
"".date("H")."",
"".date("i")."",
"".date("s")."",
"{$x} {$y} {$z}",
);
$db=str_replace($target,$targets,$this->config->get("底部显示的编辑"));
$player->sendPopup("{$db}");
break;
case "关闭":
break;
}
}
}

public function onPLayerJoin(PlayerJoinEvent $event){
$event->setJoinMessage(null);
$player=$event->getPlayer();
$name=$player->getName();
$send=$this->config->get("玩家/op加入信息发送方式");
$kq=$this->config->get("是否开启玩家/op加入提示");
switch($kq){
case "开启":
$join=array(
"{n}",
);
$joins=array(
"{$name}",
);
$opjoining=str_replace($join,$joins,$this->config->get("op加入服务器提示"));
$join1=array(
"{n}",
);
$join2=array(
"{$name}",
);
$joining=str_replace($join1,$join2,$this->config->get("玩家加入服务器提示"));
if($player->isOp()){
$aztl2=$opjoining;
}else{
$aztl2=$joining;
}
switch($send){
case "popup":
$this->getServer()->BroadCastPopup("{$aztl2}");
break;
case "message":
$this->getServer()->BroadCastMessage("{$aztl2}");
break;
case "tip":
$this->getServer()->BroadCastTip("{$aztl2}");
break;
}
break;
case "关闭":
break;
}
}

public function onPLayerQuit(PlayerQuitEvent $event){
$event->setQuitMessage(null);
$player=$event->getPlayer();
$name=$player->getName();
$send2=$this->config->get("玩家/op退出信息发送方式");
$kq2=$this->config->get("是否开启玩家/op退出提示");
switch($kq2){
case "开启":
$quit1=array(
"{n}",
);
$quit2=array(
"{$name}",
);
$opquiting=str_replace($quit1,$quit2,$this->config->get("op退出服务器提示"));
$quit=array(
"{n}",
);
$quits=array(
"{$name}",
);
$quiting=str_replace($quit,$quits,$this->config->get("玩家退出服务器提示"));
if($player->isOp()){
$aztl=$opquiting;
}else{
$aztl=$quiting;
}
switch($send2){
case "popup":
$this->getServer()->BroadCastPopup("{$aztl}");
break;
case "message":
$this->getServer()->BroadCastMessage("{$aztl}");
break;
case "tip":
$this->getServer()->BroadCastTip("{$aztl}");
break;
}
break;
case "关闭":
break;
}
}

public function onPlayerDeath(PlayerDeathEvent $event){
$event->setDeathMessage(null);
$player=$event->getPlayer();
$name=$player->getName();
$send3=$this->config->get("玩家死亡信息发送方式");
$kq3=$this->config->get("是否开启玩家死亡信息发送");
switch($kq3){
case "开启":
$death=array(
"{n}",
);
$deaths=array(
"{$name}",
);
$deathing=str_replace($death,$deaths,$this->config->get("玩家死亡信息提示"));
switch($send3){
case "popup":
$this->getServer()->BroadCastPopup("{$deathing}");
break;
case "message":
$this->getServer()->BroadCastMessage("{$deathing}");
break;
case "tip":
$this->getServer()->BroadCastTip("{$deathing}");
break;
}
break;
case "关闭":
break;
}
}

public function Chat(PlayerChatEvent $event){
$msg=$event->getMessage();
$c=mt_rand(0,15);
if($c==0){ $w="§0"; }
if($c==1){ $w="§1"; }
if($c==2){ $w="§2"; }
if($c==3){ $w="§3"; }
if($c==4){ $w="§4"; }
if($c==5){ $w="§5"; }
if($c==6){ $w="§6"; }
if($c==7){ $w="§7"; }
if($c==8){ $w="§8"; }
if($c==9){ $w="§9"; }
if($c==10){ $w="§a"; }
if($c==11){ $w="§b"; }
if($c==12){ $w="§c"; }
if($c==13){ $w="§d"; }
if($c==14){ $w="§e"; }
if($c==15){ $w="§f"; }
$ltkq=$this->config->get("是否开启聊天框美化");
switch($ltkq){
case "开启":
$event->setMessage($w.$msg);
break;
case "关闭":
break;
}
}

public function Killed(PlayerDeathEvent $event){
$ldamage=$event->getEntity()->getLastDamageCause(); 
$killkq=$this->config->get("是否开启杀人信息提示");
switch($killkq){
case "开启":
if($ldamage instanceof EntityDamageByEntityEvent){
$dmsg=str_replace("{kill}",$ldamage->getDamager()->getPlayer()->getName(),$this->Msg->get("杀人信息提示编辑"));
$dmsg=str_replace("{killed}",$event->getPlayer()->getName(),$dmsg);
$event->setDeathMessage($dmsg);
}
break;
case "关闭":
break;
}
}
}

