<?php

namespace SaMoneyFt;
/*Author:SaucdX1122;
*Plugin Name:SaMoneyFt;
*Make time:2016.05.28;
*此插件使用ITX_PM编写;
*经济API;
*所有版权:SaucdX1122
*/

use pocketmine\event\Listener;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\scheduler\PluginTask;
use pocketmine\scheduler\CallbackTask;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use onebone\economyapi\EconomyAPI;
class Main extends PluginBase implements Listener{
    public function onEnable(){
    $this->getLogger()->info("§a浮空经济富豪榜加载中.........");
     	 	$this->getLogger()->info("§b正在检测插件是否有经济API");
  		if(!$this->getServer()->getPluginManager()->getPlugin("EconomyAPI") == true) { 			$this->getLogger()->info("§eERROR§4无法找到经济API请安装经济API插件否则将无法本插件！");
  		  		}elseif($this->getServer()->getPluginManager()->getPlugin("EconomyAPI") == true) { 			$this->getLogger()->info("§b检测到您安装了§a经济API,正在加载配置文件");
  		  		 $this->getLogger()->info("§a配置文件加载成功！！！！");
        @mkdir($this->getDataFolder());
    $this->particles = new Config($this->getServer()->getDataPath()."/plugins/SaMoneyFt/"."SaMoneyPos.yml", Config::YAML, []);
    	$this->config = new Config($this->getServer()->getDataPath()."/plugins/SaMoneyFt/"."Config.yml",Config::YAML,[
	  "SamoneyftConfig" => "§e======SaMoneyFt======",
    ]);

    $this->particle = $this->particles->getAll();
    $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this,"callback"]),5*20);
    $this->getLogger()->info("插件全部运行完成");
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    }
	

 public function getRichList($page=1){
 $message=$this->config->get("SamoneyftConfig");

 $jc = EconomyAPI::getInstance()->getAllMoney();
 $jc = $jc['money'];
	arsort($jc);
	$r = "{$message}\n";
	$num = 0;		
 foreach($jc as $k => $v){
	$num++;
 if($num > 13){
 break;
 }
 $r .= "    §a[{$num}]>>§bPlayerID:§c{$k}         §d¥Money:§3{$v}\n";
 }
	return $r;
 }

 public function callback(){
	foreach($this->particle as $key => $value){
	$pos = explode(":",$key);
	$level = $this->getServer()->getLevelByName($pos[3]);
 $particle = new FloatingTextParticle(new Vector3($pos[0],$pos[1],$pos[2]),"","{$this->getRichList()}");
 $level->addParticle($particle);
 $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this,"Hide"],[$particle]),3*20);
 unset($key,$value,$level,$pos);
	}
 }
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
	   switch($command->getName()){
      case "saftset":
 $x = (int)$sender->x;
 $y = (int)$sender->y;
 $z = (int)$sender->z;
 $level = $sender->getLevel()->getFolderName();
 $this->particle[$x.":".$y.":".$z.":".$level] = $sender->getName();
 $this->particles->setAll($this->particle);
 $this->particles->save();
 $sender->sendMessage("§a>>你成功在§3X{$x}§6Y{$y}§9Z{$z}坐标§a添加了一个富豪榜！！！");
 unset($x,$y,$z,$level,$sender,$args,$command);
 return true;
 break;
   case "saftdel":
  $sender->sendMessage("§a>>成功删除富豪榜");
   $ft=$this->particles->getAll();
  
     $this->vip->remove($ft);
    $this->vip->save();
  
    return true;
 break;
 }





 }

 public function Hide($particle){
 $particle->setInvisible(false);
 }
}



