<?php

/*
  __   __                                        ______              __
  \ \  \ \                                      / _____\            / /
   \ \__\ \  __    __  _____   _____    ____   / / ____    _____   / /         
    \  ___ \ \ \  / / / ___ \ / ___ \  / ___\ / / /___ \  / ___ \ /_/
     \ \  \ \ \ \/ / / /__/ // _____/ / /     \ \____/ / / /__/ / __
      \_\  \_\ \  / / _____/ \______//_/       \______/  \_____/ /_/
              _/ / / /
             /__/ /_/

                      HyperGo!|Copyright © 保留所有权利
                           Powered By HyperGo!
                            author HyperLife
*/

namespace JoinToSendTitleGo;

use pocketmine\server;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\network\protocol\Info;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;

class JoinToSendTitleGo extends PluginBase implements Listener{

 public function onEnable(){
 
  $this->getServer()->getPluginManager()->registerEvents($this,$this);
  //插件启动提示
  
  if(Info::CURRENT_PROTOCOL<"105"){
   $this->getServer()->getLogger()->info("§cJoinToSendTitleGo启动失败, 失败原因: 服务端版本低于v1.0.5 .");
  }
  else{
   $this->getServer()->getLogger()->info("§eJoinToSendTitleGo§a已成功运行在PHP版本为: §e".(PHP_VERSION)."§a的§e".(PHP_OS)."§a系统上.");
  }
 
  //创建配置文件
  @mkdir($this->getDataFolder(),0777,true);
  
  $this->config=new Config($this->getDataFolder()."JoinToSendTitleGo.yml",Config::YAML,array(
  "提示"=>"&为换行, @为玩家名称",
  "第一行"=>"§6Minecraft §eServer",
  "第二行"=>"§bWelcome to the MCPE server!",
  "第三行"=>"§eHave a nice game"
  )
  );
 }

 public function onPlayerJoin(PlayerJoinEvent $joinMsg){
  if(Info::CURRENT_PROTOCOL>="105"){
   $playerName=$joinMsg->getPlayer()->getName();
   
   //获取服务端的名称
   $serverName=$this->getServer()->getName();
 
   //字符转义
   $target=array("&","@");
   $targets=array("\n",$playerName);
  
   $one=str_replace($target,$targets,$this->config->get("第一行"));
   $two=str_replace($target,$targets,$this->config->get("第二行"));
   $three=str_replace($target,$targets,$this->config->get("第三行"));
  
   if($serverName=="Tesseract" OR $serverName=="GenisysPro"){
    //延迟一秒发送
    sleep(1);
    //发消息给玩家
    $joinMsg->getPlayer()->sendTitle($one,$two,1,5,1);
    $joinMsg->getPlayer()->sendActionBar($three,1,5,1);
   }
   else{
    //延迟一秒发送
    sleep(1);
    //发消息给玩家
    $joinMsg->getPlayer()->addTitle($one,$two,1,5,1);
    $joinMsg->getPlayer()->addActionBarMessage($three,1,5,1);
   }
  
   //屏蔽系统提示
   $joinMsg->setJoinMessage(null);
  }
 }

 public function onDisable(){
  //插件卸载提示
  $this->getServer()->getLogger()->info("§aJoinToSendTitleGo已安全卸载!");
 }

}
