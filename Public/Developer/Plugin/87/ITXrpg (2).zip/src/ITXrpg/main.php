<?php
/**
有4种职业，分别为§a精灵使、§8魔刀客、§6圣剑士、§3武夫
玩家输入/zy 职业名（精灵使、魔刀客、圣剑士、武夫）即可加入所选职业。
可在后台配置设置某职业不可使用的物品，当使用不可使用的物品时，消息栏会提示§4无法使用改职业武器
职业可头部显示
格式：§3玩家名 职业名（带颜色字体） §e等级
武器合成
op输入/fghc 名称 合成fg武器ID 数量 合成所需武器ID 特殊值 数量 合成所需物品ID 特殊值 数量 合成所需物品ID 特殊值 数量 合成所需金钱 合成所需物品不足时消息栏提示    OP输入后放置一个木牌即可生成合成木牌，玩家点击即可合成。（武器名称、合成所需品、金钱、合成所需物品不足时提示可在后台配置了修改）
木牌格式
§a合成木牌
§e点击合成
武器名称（读取op输入合成指令时的武器名称）
空
 */
namespace tiprpg;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\inventory\Inventory;
use pocketmine\scheduler\CallbackTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockPlaceEvent;
class main extends PluginBase implements Listener
{
    public function onEnable()
    {
        $this->getLogger()->warning("===插件作者 White===");
        $this->server = $this->getServer();
        $this->server->getPluginManager()->registerEvents($this, $this);
        @mkdir($this->getDataFolder(), 0777, true);
        @mkdir($this->getDataFolder());
        $this->player = (new Config($this->getDataFolder() . "player.yml", Config::YAML));
        $this->shop = (new Config($this->getDataFolder() . "shop.yml", Config::YAML));
        $this->arm = (new Config($this->getDataFolder() . "arm.yml", Config::YAML));
        $this->wl = (new Config($this->getDataFolder() . "wl.yml", Config::YAML));
        $this->c = $this->player->getAll();
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "load"]), 40);
    }

    public function onDisable()
    {
        $this->player->setAll($this->c);
        $this->player->save();

    }

    public function onSignChange(SignChangeEvent $event)
    {
        if ($event->getLine(0) == "木牌商店") {
            $p = $event->getPlayer();
            if ($p->isOp()) {
                $block = $event->getBlock();
                $shopv3 = $this->shirtshop($block);
                $this->shop->set($shopv3, array(
                    "物品1" => array(
                        "开启" => true,
                        "ID" => 1,
                        "特殊值" => 0,
                        "数量" => 1,
                    ),
                    "物品2" => array(
                        "开启" => true,
                        "ID" => 1,
                        "特殊值" => 0,
                        "数量" => 1,
                    ),
                    "执行指令" => "arm # aa",
                    "提示语" => "t",
                    "money" => 10000,
                ));
                $this->shop->save();
                $p->sendMessage("success");
            } else {
                $p->sendMessage("233");
                $event->setLine(0, "我是大傻逼");
            }
        }
    }

    public function shirtshop($block)
    {
        $x = $block->getX();
        $y = $block->getY();
        $z = $block->getZ();
        $level = $block->getLevel()->getFolderName();
        $getall = "" . $x . ":" . $y . ":" . $z . ":" . $level . "";
        return $getall;
    }

    public function OnPlayerIteract(PlayerInteractEvent $event)
    {
        $block = $event->getBlock();
        if ($event->getBlock()->getID() == 323 or $event->getBlock()->getID() == 63 or $event->getBlock()->getID() == 68) {
            $shopv3 = $this->shirtshop($block);
            if ($this->shop->exists($shopv3)) {
                $res = $this->shop->get($shopv3);
                $inv = $event->getPlayer()->getInventory();
                $cs = true;
                if (EconomyAPI::getInstance()->reduceMoney($event->getPlayer()->getName(), $res["money"]) === EconomyAPI::RET_INVALID) {
                    $event->getPlayer()->sendMessage("§e钱不足");
                }
                if ($res["物品1"]["开启"] == true) {
                    if (!$inv->contains(new Item($res["物品1"]["ID"], $res["物品1"]["特殊值"], $res["物品1"]["数量"]))) {
                        $cs = false;
                    }
                }
                if ($res["物品2"]["开启"] == true) {
                    if (!$inv->contains(new Item($res["物品2"]["ID"], $res["物品2"]["特殊值"], $res["物品2"]["数量"]))) {
                        $cs = false;
                    }
                }
                if ($cs == true) {
                    $names = $event->getPlayer()->getName();
                    $cmd = str_replace("#", $names, $res["执行指令"]);
                    if ($res["物品1"]["开启"] == true) {
                        if (!$inv->contains(new Item($res["物品1"]["ID"], $res["物品1"]["特殊值"], $res["物品1"]["数量"]))) {
                            $cs = false;
                        } else {
                            $inv->removeItem(new Item($res["物品1"]["ID"], $res["物品1"]["特殊值"], $res["物品1"]["数量"]));
                        }
                    }
                    if ($res["物品2"]["开启"] == true) {
                        if (!$inv->contains(new Item($res["物品2"]["ID"], $res["物品2"]["特殊值"], $res["物品2"]["数量"]))) {
                            $cs = false;
                        } else {
                            $inv->removeItem(new Item($res["物品2"]["ID"], $res["物品2"]["特殊值"], $res["物品2"]["数量"]));
                        }
                    }
                    $this->getServer()->dispatchCommand(new ConsoleCommandSender(), $cmd);
                } else {
                    $mess = $res["提示语"];
                    $event->getPlayer()->sendMessage("$mess");
                }
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args)//commands
    {
        switch ($command->getName()) {
            case "sea":
                $name = $sender->getName();
                if ($args[1] == "精灵使" or $args[1] == "魔刀客" or $args[1] == "圣剑士" or $args[1] == "武夫") {
                    if (!isset($this->c[$name])) {
                        $this->c[$name] = $args[1];
                        $sender->sendMessage("§a职业选择完成");
                        if ($args[1] == "武夫") {
                            $sender->setMaxHealth(100);
                        } else if ($args[1] == "精灵使") {
                            $sender->setMaxHealth(40);
                        } else if ($args[1] == "魔刀客" or $args[1] == "圣剑士") {
                            $sender->setMaxHealth(60);
                        }
                    } else {
                        $sender->sendMessage("§a尼玛的智障选过职业了艹");
                    }
                } else {
                    $sender->sendMessage("§a尼玛的职业不存在");
                }
                break;
            case "sq":
                $this->arm->set($args[0], $args[1]);
                $this->arm->save();
                $sender->sendMessage("§asuccess");
        }
        return true;
    }

    public function onHurt(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $item = $damager->getInventory()->getItemInHand();
                if (isset($item->getNamedTag()["customData"]["simpleName"])) {
                    if ($this->arm->exists($item->getNamedTag()["customData"]["simpleName"])) {
                        $needable = $this->arm->get($item->getNamedTag()["customData"]["simpleName"]);
                        if (in_array($damager->getName(), $this->c)) {
                            $need = $this->c[$damager->getName()];
                            if ($needable !== $need) {
                                $event->setDamage(0);
                                $damager->sendMessage("§a禁止武器");
                            }
                        }
                    }
                }
            }
        }
    }

    public function welcome(PlayerJoinEvent $event)
    {
        $name = $event->getPlayer()->getName();
        if (isset($this->c[$name])) {
            $zy = $this->c[$name];
        } else {
            $zy = '无';
        }
        $exp = $event->getPlayer()->getExpLevel();
        $event->getPlayer()->setNameTag("§c✟§b$name §c✟\n§c✟§d$zy §c✟\n§c✟§e$exp 级§c✟");
    }

    public function load()
    {
        foreach ($this->server->getOnlinePlayers() as $entity) {
            $name = $entity->getName();
            if (isset($this->c[$name])) {
                if ($this->c[$name] == "武夫") {
                    $effect = Effect::getEffect(10);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                } else if ($this->c[$name] == "精灵使") {
                    $effect = Effect::getEffect(10);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                    $effect = Effect::getEffect(1);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                } else if ($this->c[$name] == "魔刀客") {
                    $effect = Effect::getEffect(5);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(1);
                    $entity->addEffect($effect);
                    $effect = Effect::getEffect(10);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                } else if ($this->c[$name] == "圣剑士") {
                    $effect = Effect::getEffect(10);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                    $effect = Effect::getEffect(11);
                    $effect->setDuration(1000);
                    $effect->setAmplifier(0);
                    $entity->addEffect($effect);
                }
            }
        }
    }

    public function on(EntityDamageEvent $event)
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            $entity = $event->getEntity();
            if ($damager instanceof Player and !$entity instanceof Player) {
                if ($damager->getGamemode() == 0 or $this->wl->exists($damager->getName())) {
                    if (floor($damager->Y) !== floor($entity->Y)) {
                        $event->setDamage(0);
                        $damager->sendMessage("§a can not fight!");
                    }
                }
            }
        }
    }
}