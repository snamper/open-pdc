<?php

namespace DisableFlow;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\block\Block;
use pocketmine\block\Lava;
use pocketmine\block\Water;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class MainClass extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("[DisableFlow] ".TextFormat::DARK_GREEN . "禁止水和岩浆流动开启");
    }

	public function onDisable(){
		$this->getLogger()->info("[DisableFlow] ".TextFormat::DARK_RED . "禁止水和岩浆流动关闭");
	}

	public function onBlockUpdate(BlockUpdateEvent $event){
		$Block = $event->getBlock();
		if(($Block instanceof Water) OR ($Block instanceof Lava)){
			$event->setCancelled(true);
		}
	}
}
