<?php

namespace DisableTntExplosion;

use pocketmine\event\Listener;
use pocketmine\event\entity\ExplosionPrimeEvent;
use pocketmine\entity\PrimedTNT;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class MainClass extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("[DisableTntExplosion] ".TextFormat::DARK_GREEN . "禁止TNT爆炸开启");
    }

	public function onDisable(){
		$this->getLogger()->info("[DisableTntExplosion] ".TextFormat::DARK_RED . "禁止TNT爆炸关闭");
	}

	public function onExplosion(ExplosionPrimeEvent $event){
		if($event->getEntity() instanceof PrimedTNT){
			$event->setCancelled(true);
		}
	}
}
