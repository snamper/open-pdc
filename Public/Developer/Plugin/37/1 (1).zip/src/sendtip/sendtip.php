<?php

namespace sendtip;

use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\Server;
use sendtip\CallbackTask;
use onebone\economyapi\EconomyAPI;
use pocketmine\level\Level; 
use pocketmine\inventory\Inventory;

 



class sendtip extends PluginBase{

 public function onEnable(){
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this,"sendsendtip"]), 9);


 $this->getLogger()->info("sendtip插件加载 by:didou");

 }

 
 
  	public function sendsendtip(){

   		       

     	
   	$z = count($this->getServer()->getOnlinePlayers());
//获取在线人数
		date_default_timezone_set('Asia/Chongqing'); //解决8小时差
		foreach($this->getServer()->getOnlinePlayers() as $player){


			 	if($player->isOnline()){
			 	
       	
		

 			
		 $m = EconomyAPI::getInstance()->myMoney($player->getName());
      $beibao = $player->getInventory();
	   $item = $beibao->getItemInHand();
      $id = $item->getID();
      $sl = $item->getcount();
      $ts = $item->getDamage();
			    if ($player->isOp()) {
                   $quanxian = "OP";
                } else {
                    $quanxian = "玩家";
}
                
       



				$player->sendPopup("§b|在线人数 : $z  §a金币: $m §2手持: $id:$ts §d数量: $sl \n§f|§e权限 : $quanxian  §b当前时间 ".date("H")." :".date("i")." :".date("s")."  §4当前地图 : ".$player->getLevel()->getName());
	

 
}
}




} 
 }
