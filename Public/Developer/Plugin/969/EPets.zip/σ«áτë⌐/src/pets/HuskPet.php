<?php

namespace pets;

class HuskPet extends Pets{

const NETWORK_ID = 53;

    Public function getName(){
        return "HuskPet";
   }

    Public function getSpeed(){
       return 1.0;
    }
 }
