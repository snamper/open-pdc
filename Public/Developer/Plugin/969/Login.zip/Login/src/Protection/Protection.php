<?php
namespace Protection;

use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
//use pocketmine\Server;
use pocketmine\level\Position;
use pocketmine\entity\Effect;
use pocketmine\level\Level;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\CallbackTask;

use Protection\database\Sban;
use Protection\database\PConfig;
use Protection\database\Message;
use Protection\UpDate\UpDate;


class Protection extends PluginBase implements Listener{
	
	private $login,$newplayer,$timertimeout,$Ptimer,$move;
	private $pper = array();
	
	public function onLoad(){
		$this->path = $this->getDataFolder();
		@mkdir($this->path);
		@mkdir($this->path."/Players");
		$this->newplayer=$this->path."/Players/";
	}
	public function onEnable(){ 
	    $this->db = new Message($this->path);
		$this->conf = new PConfig($this->path);
		$this->sban = new Sban($this->path);
		$this->keys = new Config($this->path."keys.yml", Config::YAML);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->url = "http://plugins.mcpe.cn/UpPlugins/upprotection.php";	
		$this->getServer()->getPluginManager()->registerEvents(new UpDate($this), $this);
		//$this->getLogger()->info(TextFormat::BLUE."插件加载成功");
	}
	public function onJoin(PlayerJoinEvent $event){
	    $player = $event->getPlayer();
		$user = strtolower($player->getName());
		$id = $player->getName();
		$tf=$this->conf->get("use-keys");
		$ip=$player->getAddress();
		date_default_timezone_set('Asia/Chongqing'); //系统时间差8小时问题
		$this->timertimeout[$user] = true;//true 为计算登入超时
        $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this,"timeout"],[$event]), $this->conf->get("login-timeout")*20);
	    $this->Ptimer[$user] = true;//true 为计算密码泄露
			$player->addEffect(Effect::getEffect(14)->setDuration(20 * 20000000)->setAmplifier(255)->setAmbient(false)->setVisible(false));
		if(strlen($player->getName()) > $this->conf->get("Username-length")){
			return $player->sendMessage("对不起，您的用户名过长禁止注册");
		}
		if(!file_exists($this->newplayer."$user.yml")){
		$p = new Config($this->newplayer."$user.yml", Config::YAML, array(
			"username"=>$user,
			"address"=>null,
			"last-day"=>null,
			"last-hour"=>null,
			"password"=>null,
			"links"=>4
		));
		$p->save();				
	    $this->getServer()->getLogger()->info(TextFormat::YELLOW."$id ".TextFormat::BLUE."第一次加入服务器建立数据成功");	
		unset($p);
		}
		$pp = new Config($this->newplayer."$user.yml", Config::YAML);
		$sip=$pp->get("address");
		$sday=$pp->get("last-day");
		$shour=$pp->get("last-hour");
		$ttt=$pp->get("links");
        $day=date("d");
		$hour=date("H");
		if($ttt == "0"){
		if($sip == $ip and $day == $sday and ($hour < ($shour+2))){
		$event->getPlayer()->sendMessage("");
        unset($this->timertimeout[$user]);
	    $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this,"PPtimer"],[$user]), 10*20);
		$this->getServer()->getLogger()->info("");
		$event->getPlayer()->sendMessage("§6§l自动登录成功");
			$player->addEffect(Effect::getEffect(14)->setDuration(0 * 0)->setAmplifier(0)->setAmbient(false)->setVisible(false));
		$this->pper[$user] = "on";
		}else{
		$pp->set("links",1);
		}}elseif($ttt > 1){
		$pp->set("links",4);
		if($tf == "on"){
		$pp->set("links",5);}
		$this->getServer()->getLogger()->info(TextFormat::RED."[注册账号]$id 未注册账号");}
		$pp->save();
		$this->trust($event,$pp);
        unset($pp);
	}	
	public function onCmdandChat(PlayerCommandPreprocessEvent $event){
		$player = $event->getPlayer();
	    $user = strtolower($player->getName());
		if(strlen($player->getName()) > $this->conf->get("Username-length")){
		    $event->setCancelled(true);
			return $player->sendMessage("§7§lYour name is too long!");
		}
		$id = $player->getName();
		$m = $event->getMessage();
		$ip = $player->getAddress();
		date_default_timezone_set('Asia/Chongqing'); //系统时间差8小时问题
		$day=date("d");
		$hour=date("H");
		$pp =new Config($this->newplayer."$user.yml", CONFIG::YAML);
		$ttt=$pp->get("links");
	    if($ttt !== 0){$event->setCancelled(true);}
		if($ttt == 5){
			$keys = $this->keys->getall();
			if(isset($keys[$m])){
			$pp->set("username","$user");
			if($keys[$m] == 1){
			unset($keys[$m]);
			}else{
			$keys[$m]--;}
			$this->keys->setall($keys);
			$pp->set("links",$ttt-1);
			$pp->save();
		    $player->sendMessage(TextFormat::BLUE."Ψ恭喜你激活成功~！");
			$this->keys->save();
            $this->trust($event,$pp);
	        return $this->getServer()->getLogger()->info(TextFormat::RED."[激活账号]$id 使用激活码$m 激活成功!");
			}else{
			return $player->sendMessage(TextFormat::RED."Ψ对不起，此为无效激活码！");}
			}
        if($ttt == 4){
		if($m==$id){
			$pp->set("links",$ttt-1);
			$pp->save();
			$player->sendMessage(TextFormat::BLUE."");
            return $this->trust($event,$pp);
			}else{
			$player->sendMessage("");
			return $player->sendMessage("");
		}}
		if($ttt == 3){
		    $m=trim($m);
			$pp->set("password",$m);
			$pp->set("links",$ttt-1);
			$pp->save();
			$player->sendMessage(TextFormat::GOLD."");
           return $this->trust($event,$pp);
			}
        if($ttt == 2){
			$re=$pp->get("password");
			if($m==$re){
			$time = date("y-m-d-H-i");
		    $pp->set("links",0);
			$pp->set("register-time","$time");
			$pp->save();
			unset($this->timertimeout[$user]);
			$this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this,"PPtimer"],[$user]), 10*20);
	        $player->sendMessage("§a§l注册成功");
			$player->addEffect(Effect::getEffect(14)->setDuration(0 * 0)->setAmplifier(0)->setAmbient(false)->setVisible(false));
			$this->pper[$user] = "on";
            $this->trust($event,$pp);	
	        return $this->getServer()->getLogger()->info(TextFormat::RED."[玩家注册]$id 成功完成注册!");
			}elseif($m=="remove"){
			$pp->set("links",$ttt+1);
			$pp->save();
			return $this->trust($event,$pp);
			}else{
			$player->sendMessage(TextFormat::RED."§c§l密码错误");
            return $this->trust($event,$pp);
			}
		}
        $reg = $pp->get("password");
        if($ttt == 1){
			if(!$m == NULL){
			if($m == $reg){
			$pp->set("links",$ttt-1);
			$pp->set("last-day",$day);
			$pp->set("last-hour",$hour);
			$pp->set("address",$ip);
			$pp->save();
			unset($this->timertimeout[$user]);
			$this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this,"PPtimer"],[$user]), 10*20);
	        $this->getServer()->getLogger()->info(TextFormat::YELLOW."");	
			$this->pper[$user] = "on";
	        return $player->sendMessage(TextFormat::GOLD."§a§l登录成功");
			$player->addEffect(Effect::getEffect(14)->setDuration(0 * 0)->setAmplifier(0)->setAmbient(false)->setVisible(false));
            }else{ 
			return $player->sendMessage(TextFormat::RED."§c§l密码错误");
			}}}
        if(isset($this->Ptimer[$user])){
        if($m == $reg){
        $player->sendMessage("");
	    $event->setCancelled(true);
		}}
		if($this->conf->get("compel-use-sban") == "on" ){
			$m=\explode(" ",$m);
			$cmd = strtolower($m[0]);
			if($cmd == "/ban"){
				$cmd = "sban add ";
				if(isset($m[1])){
				$cmd .= $m[1];}
				$this->getServer()->dispatchCommand($player,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "/pardon"){
				$cmd = "sban remove ";
				if(isset($m[1])){
				$cmd .= $m[1];}
				$this->getServer()->dispatchCommand($player,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "/banlist"){
				$cmd = "sban list";
				$this->getServer()->dispatchCommand($player,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "/banip"){
				$player->sendMessage("[Sban] 使用/sban add [ID] 就会自动Ban 玩家和IP");
				$event->setCancelled(true);
			}
		}
	}
	public function trust($event,$pp){
		$player=$event->getPlayer();
		if(strlen($player->getName()) > $this->conf->get("Username-length")){
			return $player->sendMessage("对不起，您的用户名过长禁止注册");
		}
		$t=$pp->get("links");
		if($t > 0){
		$player->sendMessage($this->db->qu->get($t)["a"]);
		$player->sendMessage($this->db->qu->get($t)["b"]);
		$player->sendMessage($this->db->qu->get($t)["c"]);
		}
	}
	public function onServercmd(ServerCommandEvent $event){
		$sender = $event->getSender();
	    $m = $event->getCommand();
		if($this->conf->get("compel-use-sban") == "on" ){
			$m=\explode(" ",$m);
			$cmd = strtolower($m[0]);
			if($cmd == "ban"){
				$cmd = "sban add ";
				if(isset($m[1])){
				$cmd .= $m[1];}
				$this->getServer()->dispatchCommand($sender,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "pardon"){
				$cmd = "sban remove ";
				if(isset($m[1])){
				$cmd .= $m[1];}
				$this->getServer()->dispatchCommand($sender,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "banlist"){
				$cmd = "sban list";
				$this->getServer()->dispatchCommand($sender,$cmd);
				$event->setCancelled(true);
			}
			if($cmd == "banip"){
				$sender->sendMessage("[Sban] 使用/sban add [ID] ".TextFormat::YELLOW."就会自动Ban 玩家和IP");
				$event->setCancelled(true);
			}
		}
	}
	public function timeout($event){
	$player=$event->getPlayer();
	$user=strtolower($player->getName());
	if(isset($this->timertimeout[$user])){
		if($player instanceof player){
	}
	unset($this->timertimeout[$user],$player,$user);
	}}
	public function PPtimer($user){
	unset($this->Ptimer[$user]);
	}
	public function onPlayerRespwan(PlayerRespawnEvent $event){
		$player = $event->getPlayer();
		$world = $player->getLevel()->getName();
		$user = $player->getName();
		$y = (int)$player->getY();
		if($y <= 1){
			$x = $player->getX();
		    $z = $player->getZ();
			$spawn = $this->getServer()->getDefaultLevel()->getSpawn();			
			$event->setRespawnPosition($spawn);
			$this->getServer()->getLogger()->info(TextFormat::YELLOW."$user ".TextFormat::BLUE."在虚空被Protection 修正");	
		    unset($x,$z,$spawn);
		}
		unset($player,$world,$user,$y);
	}
	public function onPlayerPreLogin(PlayerPreLoginEvent $event){
		$player = $event->getPlayer();
		$user = strtolower($player->getName());
		$ip = $player->getAddress();
		$this->pper[$user] = "off";
		$this->move[$user] = 0;
		$gsban = $this->sban->getSban($user,$ip);
		if($gsban === true){
			$event->setCancelled(true);
			$player->kick("被Sban禁止加入");
			return;
		}
		if($this->conf->get("derelogin") == "on"){
		if(isset($this->pper[$user])){
		if($this->pper[$user] == "off" ){
		    return;}
		foreach($this->getServer()->getOnlinePlayers() as $p){
			if($p !== $player and $user === strtolower($p->getName())){
				if($this->pper[$user] == "on"){
					$event->setCancelled(true);
					$player->kick("禁止重复登入");
					return;
				} 
			}
		}}}
	}
	public function onPlayerInteract(PlayerInteractEvent $event){
	    $this->permission($event);
	}		
	public function onBlockBreak(BlockBreakEvent $event){
		$this->permission($event);
	}	
	public function onEntityDamage(EntityDamageEvent $event){
		if($event->getEntity() instanceof Player){
			$user  = strtolower($event->getEntity()->getName());
			if(isset($this->pper[$user]) === false){$this->pper[$user] = "off";}
		    if($this->pper[$user] == "off" ){
			$event->setCancelled(true);}
		}
	}
	public function onBlockPlace(BlockPlaceEvent $event){
		$this->permission($event);
	}
	public function onPlayerDrop(PlayerDropItemEvent $event){
		$this->permission($event);
	}
	public function onInventoryOpen(InventoryOpenEvent $event){
		//$this->permission($event);
	}
	public function onPlayerItemConsume(PlayerItemConsumeEvent $event){
		$this->permission($event);
	}
	public function onPlayerMove(PlayerMoveEvent $event){
	    $user = strtolower($event->getPlayer()->getName());
		if(isset($this->pper[$user]) === false){
			$this->pper[$user]="off";}
		if($this->pper[$user] == "off" ){
		$this->move[$user]++;
		if($this->move[$user] >= 2){
		$event->setCancelled(true);
		$event->getPlayer()->onGround = true;
		}}
		unset($user);
	}
	public function onPickupItem(InventoryPickupItemEvent $event){
		$player = $event->getInventory()->getHolder();
		$user = strtolower($player->getName());
		if(!isset($this->pper[$user])){$this->pper[$user]=="off";}
		if($this->pper[$user] == "off" ){$event->setCancelled(true);}
	}
	public function onPlayerQuit(PlayerQuitEvent $event){
	    $player = $event->getPlayer();
	    $user = strtolower($player->getName());
		unset($this->pper[$user]);
		unset($this->timertimeout[$user]);
		unset($this->Ptimer[$user]);
	}
	public function permission($event){
	    $user = strtolower($event->getPlayer()->getName());		
		if(isset($this->pper[$user]) === false){
			$this->pper[$user]="off";}
		if($this->pper[$user] == "off" ){$event->setCancelled(true);}
		unset($user);
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		$user = strtolower($sender->getName());
		switch($command->getName()){
			case "sban":
			    if(isset($args[0])){
				$s = $args[0];
				if($s == "list" or $s == "l"){
					$banlist = $this->sban->getall();
					$n = 1;
					$out = "-------被封禁的列表-------\n";
					foreach($banlist as $name=>$ip){
						$out .=TextFormat::RED."NO.$n ".TextFormat::BLUE.$name.TextFormat::WHITE." => ".TextFormat::YELLOW."$ip\n";
					    $n++;
					}
					$sender->sendMessage($out);
				return true;}
				if(isset($args[1])){
				$user=$args[1];
				if($s == "add" or $s == "a"){
					if(file_exists($this->newplayer."$user.yml")){
						$pp = new Config($this->newplayer."$user.yml", CONFIG::YAML);
						$ip = $pp->get("address");
						if($ip == null){$ip = "未登入";}
						$p = $this->getServer()->getPlayer($user);
						if($p instanceof Player){
						$ip = $p->getAddress();
						$p->kick("被Sban踢出游戏");}
						$this->sban->set($user,$ip);
						$sender->sendMessage("[Sban] ".TextFormat::BLUE."成功封禁玩家: ".TextFormat::RED.$user.TextFormat::BLUE." 游戏IP: ".TextFormat::YELLOW.$ip);
				        return true;
					}
					$sender->sendMessage("[Sban] ".TextFormat::BLUE."$user 未加入过服务器");
				    return true;}
				elseif($s == "remove" or $s == "re"){
					$ban = $this->sban->get($user);
					if($ban != null){
						$banlist = $this->sban->getall();
						$ip = $banlist[$user];
						unset($banlist[$user]);
						$this->sban->setall($banlist);
						$sender->sendMessage("[Sban] ".TextFormat::BLUE."成功解除对玩家: ".TextFormat::RED.$user.TextFormat::BLUE." 的封禁，游戏IP： ".TextFormat::YELLOW.$ip);
				        return true;
					}
					$sender->sendMessage("[Sban] ".TextFormat::BLUE."$user 不存在封禁列表");
				    return true;}
				return false;
				}}
				return false;
			case "unregister":
			    if(isset($args[1])){
				$y=$args[0];
				$n=$args[1];
				$pp =new Config($this->newplayer."$user.yml", CONFIG::YAML);
				$reg=$pp->get("password");
				if($y==$reg){
				$pp->set("password",$n);
				$pp->save();
				$msg="[密码修改] 恭喜你成功修改密码，新密码为 $n";
			    }else{
				$msg="[密码修改] 对不起原密码输入错误！";}
				}elseif($sender instanceof Player){
				return false;
				}else{
				$msg="[密码修改] 请在游戏中使用 ！";
				}
				$sender->sendMessage($msg);
				return true;
			case "keys":
			    if(isset($args[0])){
				$aa = $args[0];
				switch($aa){
					case "off":
					$this->conf->set("use-keys","off");
					$sender->sendMessage("[提示] 激活码功能关闭");
					return true;
					case "on":
					$this->conf->set("use-keys","on");
					$sender->sendMessage("[提示] 激活码功能启用");
					return true;
				}}
				date_default_timezone_set('Asia/Chongqing'); //系统时间差8小时问题
				$m=date("m");
				$day=date("d");
				$k=0;
				$out=$m.$day;
				while($k < 4){
				$a=chr(rand(97,122));
				$b=mt_rand(0,9);
				$c=mt_rand(1,2);
				if($c==1){$aa=$b;}else{$aa=$a;}
				$out .=$aa;
				$k=$k+1;}
				$this->keys = new Config($this->path."keys.yml", Config::YAML);
				$keyc=mt_rand(1,2);
				$this->keys->set($out,$keyc);
				$this->keys->save();
				$sender->sendMessage("[提示] 生成新激活码$out 有效次数 $keyc");
				return true;
		}
	}

}