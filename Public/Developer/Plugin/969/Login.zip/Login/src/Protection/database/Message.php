<?php

namespace Protection\database;

use pocketmine\utils\Config;

class Message{
	
	public function __construct($file){
		$this->qu = new Config($file."Question.yml", Config::YAML, array(
		   "4"=>array(
		   "a"=>"",
		   "b"=>"",
		   "c"=>"§b§l请输入§cID§r"),
		   "5"=>array(
		   "a"=>"✘✘✘✘请输入激活码✘✘✘✘",
		   "b"=>NULL,
		   "c"=>NULL ),
		   "3"=>array(
		   "a"=>"§6§l✡ 输入密码✡§r ",
		   "b"=>"",
		   "c"=>""),
		   "2"=>array(
		   "a"=>"§a§l✡再次输入密码✡§r",
		   "b"=>"",
		   "c"=>NULL ),
		   "1"=>array(
		   "a"=>"",
		   "b"=>"§b§l☣输入密码以登录☣",
		   "c"=>NULL )
		));
	}

}