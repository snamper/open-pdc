<?php

namespace Protection\database;

use pocketmine\utils\Config;

class PConfig{
	
	public function __construct($file){
		$this->conf = new Config($file."Config.yml", Config::PROPERTIES, array(
			"login-timeout"=>300000,
			"derelogin"=>"off",
			"compel-use-sban"=>"off",
			"use-keys"=>"off",
			"Username-length"=>80
		));
	}
	public function get($key){
		return $this->conf->get($key);
	}
	
	public function set($key,$value){
		$this->conf->set($key,$value);
		$this->conf->save();
	}
	
}
		