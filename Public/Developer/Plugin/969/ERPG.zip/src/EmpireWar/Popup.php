<?php
namespace EmpireWar;


use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat;

class Popup extends PluginTask{
    private $plugin;

    public function __construct(EmpireWar $plugin) {
        $this->plugin = $plugin;
        parent::__construct($plugin);
    }

    public function onRun($CK){
        $online = count($this->plugin->getServer()->getOnlinePlayers());
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
			$n = $player->getName();
			$popup = TextFormat::GOLD.'§c§l种族:'.$this->plugin->getNation($n).'     ';
			$popup .= TextFormat::RED.'§e§l职位:'.$this->plugin->getExp($n).'     ';
			$popup .= TextFormat::GREEN.'§a§l积分:'.$this->plugin->getPoint($n)."   ";
			$popup .= TextFormat::RED.'§7§l杀敌人数:'.$this->plugin->getKillNumber($n).'     ';
			$popup .= "§r\n\n";
            $player->sendTip($popup);
        }
    }
}