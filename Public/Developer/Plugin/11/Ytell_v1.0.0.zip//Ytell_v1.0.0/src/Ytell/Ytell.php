<?php

namespace Ytell;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\permission\ServerOperator;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
class Ytell extends PluginBase implements Listener{
 public function onEnable(){
$this->getServer()->getPluginManager()->registerEvents($this, $this);
 $this->getServer()->getLogger()->warning("\n§e
●Yell进服消息插件已启动●\n作者xMing\n");
 $this->getServer()->getLogger()->info("\n请去修改配置文件完成进服消息设置\n");
sleep(5);
@mkdir($this->getDataFolder(),0777,true);
$this->Y=new Config($this->getDataFolder()."进服消息.yml",Config::YAML,array("温馨提示"=>"修改配置文件后重启服务器生效",
"另"=>"player代表进服玩家的名字",
"修改以下"=>"进服对玩家发送：",
"第一行"=>"§a［ 进服提示］欢迎来到YYYY服务器",
"第二行"=>"§b［ 进服提示］本服腐竹YYY，有事可以找他哦!",
"修改下边"=>"玩家进服全服通知：",
"内容"=>"§6［ 全服通知］欢迎玩家player进入服务器")
  );
  }
 public function onPlayerJoin(PlayerJoinEvent $event){
$event->setJoinMessage(null);
//清除系统提示
$name=$event->getPlayer()->getName();
//获取进服玩家名字
$target=array("player");
$targets=array("{$name}");
$one=$this->Y->get("第一行");
$two=$this->Y->get("第二行");
//获取配置文件内容
$tip=str_replace($target,$targets,$this->Y->get("内容"));
$player=$event->getPlayer();
//发生私信
sleep(2);
//间隔2秒
$player->sendMessage("$one");
sleep(1);
$player->sendMessage("$two");
sleep(1);
$this->getServer()->broadcastMessage("$tip");
//发送公告
}
 public function onDisable(){
 //插件卸载提示
  $this->getServer()->getLogger()->warning("§bYtell已安全卸载!");
}
}