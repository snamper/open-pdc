<?php
namespace ZipPluginLoader;
use pocketmine\plugin\PluginBase;

class Dummy extends PluginBase {
	public function onEnable(){}
	public function onDisable() {}
}
