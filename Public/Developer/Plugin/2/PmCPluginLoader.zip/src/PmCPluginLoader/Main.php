<?php
namespace PmCPluginLoader;

use pocketmine\plugin\PluginBase;
use pocketmine\plugin\PluginLoadOrder;

use PmCPluginLoader\PmCPluginLoader;
use PmCPluginLoader\PmCStream;

class Main extends PluginBase {
	const LOADER = "PmCPluginLoader\\PmCPluginLoader";
	public function onEnable(){
		if (!in_array("pmc",stream_get_wrappers())) {
			if (!stream_wrapper_register("pmc",__NAMESPACE__ . "\\PmCStream")) {
				$this->getLogger()->error("Unable to register PmC wrapper");
				throw new \RuntimeException("Runtime checks failed");
				return false;
			}
		}
		$this->getServer()->getPluginManager()->registerInterface(self::LOADER);
		$this->getServer()->getPluginManager()->loadPlugins($this->getServer()->getPluginPath(), ["PmCPluginLoader\\PmCPluginLoader"]);
		$this->getServer()->enablePlugins(PluginLoadOrder::STARTUP);
	}
	public function onDisable() {
		foreach ($this->getServer()->getPluginManager()->getPlugins() as $p) {
			if ($p->isDisabled()) continue;
			if (get_class($p->getPluginLoader()) == self::LOADER) {
				$this->getServer()->getPluginManager()->disablePlugin($p);
			}
		}
		if (in_array("pmc",stream_get_wrappers())) {
			stream_wrapper_unregister("pmc");
		}
	}
}
