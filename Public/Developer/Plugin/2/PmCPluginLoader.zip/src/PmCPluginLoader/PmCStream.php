<?php
namespace PmCPluginLoader;

use \SQLite3;

class Files extends SQLite3{
	public function __construct($file){
		$this->open($file);
	}
}

class PmCStream{
	private $db;
	private $path, $dbpath, $filepath;
	private $seek = 0, $length=0, $content='';
	public function stream_open($path,$mode,$opts,&$opened_path){
		$path = str_replace(['pmc://', '\\'], ['', '/'], $path);
		$path = explode('.pmc', $path);
		$dbpath = $path[0] . '.pmc';
		$this->filepath = '/'.ltrim($path[1], '/');
		$this->dbpath = $dbpath;
		if(file_exists($dbpath)){
			if($this->db = new Files($dbpath)){
				$sql = "SELECT * FROM `files` WHERE `path` = '{$this->filepath}'";
				$content = $this->db->query($sql)->fetchArray();
				if(isset($content['path'])){
					$this->length = $content['length'];
					$this->content = (~gzuncompress($content['file']));
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	public function stream_close() {
		$this->db->close();
	}
	public function stream_read($count) {
		$end = (($this->seek + $count) > $this->length)?$this->length:($this->seek + $count);
		$ret = substr($this->content, $this->seek, $end);
		$this->seek += $count;
		return $ret;
	}
	
	public function stream_seek($offset , $whence = SEEK_SET){
		$this->seek = $offset;
		return true;
	}
	public function stream_eof() {
		if(($this->seek) >= ($this->length)){
			return true;
		} else {
			return false;
		}
	}
	public function url_stat($path,$flags) {
		$path = str_replace('\\', '/', $path);
		$path = str_replace('pmc://', '', $path);
		$path = explode('.pmc', $path);
		$dbpath = $path[0] . '.pmc';
		$this->filepath = '/'.ltrim(isset($path[1])?$path[1]:'/plugin.yml', '/');
		$this->dbpath = $dbpath;
		if(file_exists($dbpath)){
			if($this->db = new Files($dbpath)){
				$sql = "SELECT * FROM `files` WHERE `path` = '{$this->filepath}'";
				$content = $this->db->query($sql)->fetchArray();
				if(isset($content['path'])){
					$zst = json_decode($content['stat'], true);
					$ret = [];
					foreach([7=>'size', 8=>'mtime',9=>'mtime',10=>'mtime'] as $a=>$b) {
						if (!isset($zst[$b])) continue;
						$ret[$a] = $zst[$b];
					}
					return $ret;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	public function stream_stat() {
		return $this->url_stat($this->path,0);
	}
}