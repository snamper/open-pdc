#鲁大师（LuDaShi）#
**PocketMine工具箱、跑分测试**

目前仅支持跑分测试


#### 指令集
```bash
ludashi test #开启跑分测试，测试cpu、io、同服mc服务器数量并加入全国排行
```
