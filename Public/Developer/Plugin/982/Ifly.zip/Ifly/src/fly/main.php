<?php

namespace ifly;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use onebone\economyapi\EconomyAPI; 
use pocketmine\event\entity\EntityLevelChangeEvent;

class main extends PluginBase implements Listener{
    public function onEnable(){
     $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("Ifly插件加载!  By:泡芙");
@mkdir($this->getDataFolder());
$this->config = new Config($this->getDataFolder()."config.yml", Config::YAML, array(
"id"=>array(),
"world"=>array(),
"cid"=>array()
));
$this->config->save();
}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		switch($command->getName()){
	case "飞行":
           $a1 = $sender->getInventory()->getHelmet()->getID();
            $a2 = $sender->getInventory()->getChestplate()->getID();
            $a3 = $sender->getInventory()->getLeggings()->getID();   
            $a4 = $sender->getInventory()->getBoots()->getID();
if($a1 == 302||$a2 == 303||$a3 == 304||$a == 305){
					$fly = $sender->getAllowFlight();
							$sender->setAllowFlight(!$fly);
							if($fly){
		$sender->sendMessage("关闭飞行");
								return true;
							}else{
		$sender->sendMessage("开启飞行");
								return true;
							}
}
if(in_array($sender->getName(),$this->config->get("id"))){
$sender->sendMessage("§c你已被禁止使用飞行");
								return true;
}
if(in_array($sender->getClientId(),$this->config->get("cid"))){
$sender->sendMessage("§c你已被禁止使用飞行");
								return true;
}
if(in_array($sender->getLevel()->getFolderName(),$this->config->get("world"))){
$sender->sendMessage("§c你所在世界禁止飞行!");
								return true;
}
					$fly = $sender->getAllowFlight();
							$sender->setAllowFlight(!$fly);
							if($fly){
		$sender->sendMessage("关闭飞行");
								return true;
							}else{
		$sender->sendMessage("开启飞行");
								return true;
							}
break;
			case "禁止飞行":
if (count($args) != 1) {
 $sender->sendMessage("§c用法:/禁止飞行 <玩家ID>");
return true;
}
$id = $this->config->get("id");
$id[] = $args[0];
$this->config->set("id",$id);
$this->config->save();
 $sender->sendMessage("已禁止{$args[0]}的飞行权限");
   if ($this->getServer()->getPlayer($args[0]) instanceof Player&&$this->getServer()->getPlayer($args[0])->isOnline()) {
$p = $this->getServer()->getPlayer($args[0]);
$p->setAllowFlight(false);
$cid = $this->config->get("cid");
$cid[] = $p->getClientId();
$this->config->set("cid",$cid);
$this->config->save();
}
return true;
break;
	case "允许飞行":
if (count($args) != 1) {
 $sender->sendMessage("§c用法:/允许飞行 <玩家ID>");
return true;
}
$id = $this->config->get("id");
$inv = array_search($args[0], $id);
$inv = array_splice($id, $inv, 1);
$this->config->set("id",$id);
$this->config->save();
 $sender->sendMessage("已解禁{$args[0]}的飞行权限");
   if ($this->getServer()->getPlayer($args[0]) instanceof Player&&$this->getServer()->getPlayer($args[0])->isOnline()) {
$p = $this->getServer()->getPlayer($args[0]);
$cid = $this->config->get("cid");
$inv = array_search($p->getClientId(), $cid);
$inv = array_splice($cid, $inv, 1);
$this->config->set("cid",$cid);
$this->config->save();
}
return true;
break;
}}

   public function onWorldChange(EntityLevelChangeEvent $event) {
$player = $event->getEntity();
$newworld = $event->getTarget();
if($player instanceof Player){
if(in_array($newworld->getFolderName(),$this->config->get("world"))){
$player->setAllowFlight(false);
}
}}
}
?>
