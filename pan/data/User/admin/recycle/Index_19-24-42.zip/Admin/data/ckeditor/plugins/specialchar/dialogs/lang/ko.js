/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("specialchar","ko",{euro:" ",lsquo:"  ",rsquo:"  ",ldquo:"  ",rdquo:"  ",ndash:" ",mdash:" ",iexcl:" ",cent:" ",pound:" ",curren:" ",yen:" ",brvbar:"Broken bar",sect:" ",uml:" ",copy:" ",ordf:"Feminine ordinal indicator",laquo:"   ",not:" ",reg:" ",macr:" ",deg:" ",sup2:" 2",sup3:" 3",acute:"  ",micro:" ",para:" ",middot:" ",cedil:"",sup1:" 1",
ordm:"Masculine ordinal indicator",raquo:"   ",frac14:"  ",frac12:"  ",frac34:"  ",iquest:" ",Agrave:"     A",Aacute:"      A",Acirc:"      A",Atilde:"    A",Auml:"     A",Aring:"    A",AElig:"  AE",Ccedil:"    C",Egrave:"     E",Eacute:"      E",Ecirc:"      E",Euml:"     E",Igrave:"     I",Iacute:"      I",
Icirc:"      I",Iuml:"     I",ETH:"  Eth",Ntilde:"    N",Ograve:"     O",Oacute:"     O",Ocirc:"      O",Otilde:"    O",Ouml:"     O",times:" ",Oslash:"    O",Ugrave:"     U",Uacute:"     U",Ucirc:"      U",Uuml:"     U",Yacute:"     Y",THORN:"  Thorn",szlig:"  sharp s",agrave:"     a",aacute:"     a",
acirc:"      a",atilde:"    a",auml:"     a",aring:"    a",aelig:"  ae",ccedil:"    c",egrave:"     e",eacute:"     e",ecirc:"      e",euml:"     e",igrave:"     i",iacute:"     i",icirc:"      i",iuml:"     i",eth:"  eth",ntilde:"    n",ograve:"     o",oacute:"     o",ocirc:"      o",
otilde:"    o",ouml:"     o",divide:" ",oslash:"    o",ugrave:"     u",uacute:"     u",ucirc:"      u",uuml:"     u",yacute:"     y",thorn:"  thorn",yuml:"     y",OElig:"  OE",oelig:"  oe",372:"      W",374:"      Y",373:"      w",375:"      y",sbquo:" -9  ",8219:" --9  ",bdquo:" -9  ",hellip:"  ",
trade:" ",9658:"  ",bull:" ",rarr:" ",rArr:"   ",hArr:"   ",diams:" ",asymp:""});