<?php 
$orderid=$_REQUEST['orderid'];
        $restate=$_REQUEST['restate'];
        $ovalue=$_REQUEST['ovalue'];
        $sign=$_REQUEST['sign'];
        var_dump($orderid); var_dump($restate); var_dump($ovalue); var_dump($sign);
 ?>