<?php if (!defined('THINK_PATH')) exit();?><div class="uk-width-large-2-10 uk-margin-bottom">
    <div class="uk-panel uk-panel-box uk-panel-box-secondary">
        <div class="uk-container-center" style="width: 100px;overflow: hidden;">
            <img class="img-rounded"
                 src="
            <?php if($UserSystemData['data']['avatar']){ echo C('HOST').substr($UserSystemData['data']['avatar'],2).'/avatar.jpg-avatar_100.jpg'; }else{ echo C('HOST').'/Public/images/placeholder_avatar.svg'; } ?>"
             width="100" height="100" alt="">
            <div class="uk-float-right uk-vertical-align-bottom uk-text-center" style="line-height: 23px;width: 100%;">
                <h3 class=" uk-margin-small-top"><?php echo getCanSeeName($UserSystemData);?></h3>
                <a href="<?php echo U('/User/torecharge');?>" target="_blank"><button class="btn btn-primary" type="button">余额:<?php echo ($UserSystemData["money"]); ?></button></a>
            </div>
        </div>
        <!--上面是用户的一些信息-->
        <hr class="uk-article-divider">
        <!--下面是导航-->
		<script>console.log(location.href);</script>
        <div >
            <ul class="uk-nav uk-nav-side uk-nav-parent-icon uk-container-center uk-text-center">
                <li class="<?php echo UrlLike(U('Developer/NewServer'),'uk-active');?>">
                    <a href="<?php echo U('Developer/NewServer');?>"><i class="uk-icon-user"></i> 发布服务器</a>
                </li>
                <li class="<?php echo UrlLike(U('Developer/MyServer'),'uk-active');?>">
                    <a href="<?php echo U('Developer/MyServer');?>"><i class="uk-icon-user"></i> 我的服务器</a>
                </li>
				<li class="<?php echo UrlLike(U('Developer/NewPlugin'),'uk-active');?>">
                    <a href="<?php echo U('Developer/NewPlugin');?>"><i class="uk-icon-user"></i> 发布插件</a>
                </li>
				<li class="<?php echo UrlLike(U('Developer/MyPlugin'),'uk-active');?>">
                    <a href="<?php echo U('Developer/MyPlugin');?>"><i class="uk-icon-user"></i> 我的插件</a>
                </li>
                <li class="<?php echo UrlLike(U('Developer/SellRecord'),'uk-active');?>">
                    <a href="<?php echo U('Developer/SellRecord');?>"><i class="uk-icon-user"></i> 收入统计</a>
                </li>
                <li class="<?php echo UrlLike(U('Developer/atm'),'uk-active');?>">
                    <a href="<?php echo U('Developer/atm');?>"><i class="uk-icon-user"></i> 提现申请</a>
                </li>
                <li class="<?php echo UrlLike(U('Developer/atmrecord'),'uk-active');?>">
                    <a href="<?php echo U('Developer/atmrecord');?>"><i class="uk-icon-user"></i> 提现记录</a>
                </li>
            </ul>
        </div>
        <hr class="uk-text-center">
        <div class="uk-text-center"> <a href="<?php echo U('/User');?>">进入用户中心</a></div>
    </div>
</div>