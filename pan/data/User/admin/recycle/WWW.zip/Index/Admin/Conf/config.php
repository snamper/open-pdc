<?php
return array(
	//'配置项'=>'配置值'
//    'SHOW_PAGE_TRACE'  => true,
    'TITLE' => '网站后台管理',
     'URL_CASE_INSENSITIVE' =>true,//表示不用遵守大小写
);