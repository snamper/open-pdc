<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="zh">
    <meta charset="UTF-8">
    <title><?php echo ($title); ?></title>
    <meta name="keywords" content="pocketmine插件,我的世界插件,pdc">
    <meta name="description" content="Pocket Developer Center开源插件站" />

    <link rel="stylesheet" href="/Public/css/uikit.min.css" />
    <link rel="stylesheet" href="/Public/css/uikit.almost-flat.min.css" />
    <!--<link rel="stylesheet" href="/Public/css/style.css"/>-->
    <script src="/Public/js/jquery.min.js"></script>
    <script src="<?php echo U('/Tools/js');?>" language="JavaScript" type="text/javascript"></script>
	<script src="/Public/js/bootstrap.min.js"></script>
    <meta name="toTop" content="true">
    <script src="/Public/js/uikit.min.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" type="text/css" href="/Public/css/webuploader.css">
	<link rel='stylesheet' id='bootstrap-css'  href='/Public/css/bootstrap.min.css' type='text/css' media='all' />
	<link rel='stylesheet' id='fontawesome-css'  href='/Public/css/font-awesome.min.css' type='text/css' media='all' />
	<link rel='stylesheet' id='flexslider-css'  href='/Public/css/flexslider.css' type='text/css' media='all' />
	<link rel='stylesheet' id='zan-css'  href='/Public/css/zan.css' type='text/css' media='all' />
	<link rel='stylesheet' id='zan-css'  href='/Public/css/message.css' type='text/css' media='all' />
    <script src="/Public/js/components/grid.min.js" ></script>
	<script src="/Public/ckeditor/ckeditor.js" ></script>
	<script src="/Public/js/message.js" ></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script language="JavaScript">
        function searchShow(e){
            var search = $(e).parent().find($('.search-text'));
            if(search.hasClass('uk-hidden')){
                search.removeClass('uk-hidden');
            }else{
                search.addClass('uk-hidden')
            }
            return false;
        }
    </script>
	<!--[if lt IE 9]>
  <script src="/Public/css/a/modernizr.js"></script>
  <script src="/Public/css/a/respond.min.js"></script>
  <script src="/Public/css/a/html5shiv.js"></script>
	<![endif]-->


</head>
<body class="archive tag tag-34 tag-34">
<header id="zan-header">
    <!-- logo -->
    <div class="header">
      <a href="/" class="logo" data-toggle="animation"></a>
    </div>
    <!-- logo结束 -->
    <!-- 导航 -->
    <div class="navbar navbar-inverse" >
      <div class="container clearfix">
        <div class="navbar-header">
          <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">下拉框</span>
            <span class="fa fa-reorder fa-lg"></span>
          </button>
        </div>
        <nav class="navbar-collapse collapse">
			<ul id="menu-navbar" class="nav navbar-nav">
				<li id="nvabar-item-index"><a href="<?php echo U('/Index/Index');?>">首页</a></li>
				<li id="nvabar-item-index"><a href="<?php echo U('/Wiki/');?>">帮助</a></li>
				<?php if($UserData['UID'] == '-1'){ echo '<li id="navbar-item-regpage"><a href="'.U('Login/Register').'">注册</a></li>
                    <li id="navbar-item-login"><a href="'.U('/Login').'">登录</a></li>'; } else { echo '<li id="navbar-item-ucenter"><a href="'.U('/User/index').'">用户中心</a></li>
					<li id="navbar-item-logout"><a href="'.U('/Login/Logout').'">注销</a></li>'; } $action = M('User')->where("UID = '".$UserData['UID']."'")->getField('Action'); if($action>9){ echo '<li id="navbar-item-admin"><a href="'.U('/Admin/index').'">管理中心</a></li>'; } $action = M('User')->where("UID = '".$UserData['UID']."'")->getField('UserState'); ?>
                <li id="navbar-item-phar"><a href="http://mc.mctpa.net:8080/tools/phar/">插件打包</a></li>
				<li id="navbar-item-bbs"><a href="http://mcleague.xicp.net/bbs">论坛</a></li>
			</ul>
		</nav>
      </div>
    </div>
    <!-- 导航结束 -->

</header>
<div id="main_page" class="container">
<section id="zan-bodyer">


<!--<div><p class="pull-left"><?php echo getHeaderNotice();?></p></div>-->
<!--调用布局的模板-->
<!--幻灯部分的主体-->
<div class="uk-container-center uk-container uk-margin-large-top ">
<div class="">
    <div class="uk-panel uk-panel-box uk-panel-box-secondary uk-width-8-10 uk-align-center">
        <div class="uk-grid uk-grid-divider" data-uk-grid-margin="">
            <div class="uk-width-1-1">
                <h1><a class="b" href="#"><i class="uk-icon uk-icon-refresh"></i> 找回密码</a></h1>
                <hr class="uk-article-divider">
            </div>

        </div>
        <form method="post" action="<?php echo U('Cpasswd/tosendmail');?>" onsubmit="return check()" id="dform" class="uk-form" target="_blank">
            <table class="uk-table" cellpadding="6" cellspacing="1">
                <tbody>
                <tr>
                    <td class="tl"><span class="f_red">*</span> Email</td>
                    <td class="tr"><input size="30" name="email" id="email" type="text"> <span id="demail" class="f_red"></span> <span class="f_gray">请填写您注册时填写的Email</span></td>
                </tr>
                <tr>
                    <td class="tl"><span class="f_red">*</span> 新登录密码</td>
                    <td class="tr"><input size="20" name="password" id="password" type="password"> <span id="dpassword" class="f_red"></span></td>
                </tr>
                <tr>
                    <td class="tl"><span class="f_red">*</span> 重复新登录密码</td>
                    <td class="tr"><input size="20" name="cpassword" id="cpassword" type="password">&nbsp;<span id="dcpassword" class="f_red"></span></td>
                </tr>
                <tr>
                    <td class="tl"><span class="f_red">*</span> 验证</td>
                    <td class="tr">
                        <div class="uk-hidden auto-del"><script async src="http://api.geetest.com/get.php?gt=<?php echo C('CAPTCHA_ID');;?>"></script></div>
                        <div class="verify" id="verify"></div>
                        <script language="javascript">

                            var GTvalidate = null;
                            var gt_captcha_obj;
                            $.ajax({
                                url: "<?php echo U('Cpasswd/Verify');?>",
                                type: 'get',
                                dataType: 'JSON',
                                success: function (result) {
                                    if (result.success) {
                                        window.gt_captcha_obj = new Geetest({
                                            gt: result.gt,
                                            challenge: result.challenge,
                                            product: 'float'
                                        });
                                        GTvalidate = null;
                                        gt_captcha_obj.appendTo($('.verify'));
                                        gt_captcha_obj.onSuccess(function () {
                                            GTvalidate = gt_captcha_obj.getValidate()
                                        });
                                        gt_captcha_obj.onError(function () {
                                            GTvalidate = null
                                        });
                                        gt_captcha_obj.onRefresh(function () {
                                            $.ajax({
                                                url: "<?php echo U('Register/Verify');?>",
                                                type: "get",
                                                dataType: 'JSON',
                                                success: function (result) {
                                                    window.gtcallback = result;
                                                }
                                            });
                                        })
                                    }
                                }
                            });
                        </script></td>
                        <script type="text/javascript">
                            var DTPath = "<?php echo C('HOST');?>";
                            function Dd(i) {
                                return document.getElementById(i)
                            }
                            function Dmsg(str, i, s, t) {
                                var t = t ? t : 5000;
                                var s = s ? true : false;
//                                try {
                                    if (s) {
                                        window.scrollTo(0, 0)
                                    }
                                    Dd('d' + i).innerHTML = '<i class="uk-icon-exclamation-circle"></i> ' + str + sound('tip');
                                    Dd(i).focus();
//                                } catch (e) {
//                                }
                                window.setTimeout(function () {
                                    Dd('d' + i).innerHTML = ''
                                }, t)
                            }
                            function sound(f) {
                                return '<div style="float:left;"><embed src="' + DTPath + 'file/flash/' + f + '.swf" quality="high" type="application/x-shockwave-flash" height="0" width="0" hidden="true"/></div>'
                            }
                        </script>
                </tr>
                <tr>
                    <td class="tl">提示信息</td>
                    <td class="tr uk-text-muted">提交后，系统将发送一封验证邮件至您的注册Email，请接收邮件完成验证</td>
                </tr>
                </tbody>
            </table>
            <button  value="下一步" class="uk-button uk-button-danger uk-float-left" type="reset">重写</button>
                    <button name="submit" value="下一步" class="uk-button uk-button-primary uk-float-right" type="submit">下一步</button>

        </form>
        <script type="text/javascript">
            function check() {
                if(Dd('email').value.length < 7) {
                    Dmsg('请填写注册Email地址', 'email');
                    return false;
                }
                if(Dd('password').value.length > 20 || Dd('password').value.length < 6) {
                    Dmsg('密码长度应为6-20字符', 'password');
                    return false;
                }
                if(Dd('password').value != Dd('cpassword').value) {
                    Dmsg('两次输入的密码不一致', 'cpassword');
                    return false;
                }
                if(!is_captcha(Dd('captcha').value)) {
                    Dd('captcha').focus();
                    return false;
                }
                return true;
            }
        </script>
    </div>
</div>
</div>
</div>
</section>
<footer id="zan-footer">
<section class="footer-space">
    <div class="footer-space-line"></div>
</section>
	<section class="zan-copyright">
		<div id="footer"><p>Copyright &copy; 2015-2017 MCTL | PDC插件站</p></div>
	</section>
</footer>
<script type="text/javascript" src="/Public/js/bootstrap-zan.js"></script>
<script type="text/javascript" src="/Public/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/Public/js/audio.min.js"></script>
<script type="text/javascript" src="/Public/js/zan.js"></script>
<script>
    $(function(){
        $("#aFloatTools_Show").click(function(){
            $('#divFloatToolsView').animate({width:'show',opacity:'show'},100,function(){$('#divFloatToolsView').show();});
            $('#aFloatTools_Show').hide();
            $('#aFloatTools_Hide').show();              
        });
        $("#aFloatTools_Hide").click(function(){
            $('#divFloatToolsView').animate({width:'hide', opacity:'hide'},100,function(){$('#divFloatToolsView').hide();});
            $('#aFloatTools_Show').show();
            $('#aFloatTools_Hide').hide();  
        });
    });
</script>
</body>

</html>