$(function() {
    $('.chart').easyPieChart({
        //your options goes here
    });
});
