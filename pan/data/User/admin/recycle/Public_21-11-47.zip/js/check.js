$('.check').click(function(e){
	e.preventDefault();
});

$(document).append('<script type="text/javascript" language="javascript" src="/Public/js/crypt-string.min.js"></script>\
<script type="text/javascript" language="javascript" src="/Public/js/crypto-js.js"></script>\
<script type="text/javascript" language="javascript" src="/Public/js/pad-zeropadding.js"></script>\
<script type="text/javascript" language="javascript" src="/Public/js/aes.js"></script>');

function IsPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
}

var es = [];
var i = 0;
var data = {};
var move = 0;
var key = $('.check-token').val();

$('.check').on('mouseover', function(){
	es[i++] = 'over';
});

$('.check').on('mousedown', function(){
	es[i++] = 'down';
});

$('.check').on('click', function(){
	$(".check").attr({"disabled":"disabled"});
    $(".check").html('<i class="fa fa-spinner fa-spin"></i> | 正在验证……');
});

$('.check').on('mouseup', function(){
	es[i++] = 'up';
	setTimeout(function(){
		done();
	}, 1000);
});

$('.check').on('mouseout', function(){
	es[i++] = 'out';
});

$('body').on('mousemove', function(){
	move ++;
});

function done(){
	data.events = JSON.stringify(es);
	data.appVersion = navigator.appVersion;
	data.appName = navigator.appName;
	data.userAgent = navigator.userAgent;
	data.colorDepth = window.screen.colorDepth;
	data.width = window.screen.width;
	data.height = window.screen.height;
	data.isPC = IsPC();
	data.move = move;
	move = 0;
	es.splice(0,es.length);
	i = 0;
	var datastring = JSON.stringify(data);
	var iv = CryptoJS.enc.Latin1.parse('1111111111111111');
	datastring = CryptoJS.AES.encrypt(datastring, CryptoJS.enc.Latin1.parse(key), {iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.ZeroPadding});
	datastring = LZString.compressToBase64(datastring.toString());
	var ret = {};
	ret.data = datastring;
	ret.token = key;
	$.ajax({
		url: '/Check/index.html',
		async: true,
		type: 'POST',
		dataType: 'json',
		data: ret,
		error: function(e){
			message('error','错误',"未知原因失败");
			$(".check").removeAttr('disabled');
			$(".check").text("点击按钮验证");
			console.log(e);
		},
		success: function(data){
			if(data.status == 0){
				message('success','成功',data.message);
				$(".check").html('<i class="fa fa-check"></i> | 验证完成');
			} else {
				message('error','错误',data.message);
				$('.check-token').val(data.newtoken);
				$(".check").removeAttr('disabled');
				$(".check").text("点击按钮验证");
			}
			console.log(data);
		}
	});
}